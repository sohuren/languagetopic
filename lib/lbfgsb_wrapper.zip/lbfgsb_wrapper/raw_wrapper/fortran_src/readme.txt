This directory contains source files of the original Fortran implementation of the L-BFGS-B algorithm.
